#### Discuss
Discuss with Chuning Li (260664379)
#### Extract package
math, OS, PIL
 
